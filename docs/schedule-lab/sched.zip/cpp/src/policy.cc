#include "policy.h"

Action policy(const std::vector<Event>& events, int current_cpu,
              int current_io) {
  return Action();
}